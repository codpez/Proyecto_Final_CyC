import cv2
import numpy as np
import argparse
import sys

def main():
    # Configurar el parser de argumentos
    parser = argparse.ArgumentParser(description='Procesador de Optical Flow para Videos')
    parser.add_argument('video_path', type=str, help='Ruta al archivo de video')
    args = parser.parse_args()

    # Abrir el video
    cap = cv2.VideoCapture(args.video_path)
    if not cap.isOpened():
        print(f"Error: No se pudo abrir el video '{args.video_path}'")
        sys.exit(1)

    # Leer el primer frame
    ret, old_frame = cap.read()
    if not ret:
        print("Error: No se pudo leer el primer frame del video")
        sys.exit(1)

    # Convertir a escala de grises
    old_gray = cv2.cvtColor(old_frame, cv2.COLOR_BGR2GRAY)
    
    # Crear máscaras para dibujar
    mask = np.zeros_like(old_frame)
    binary_mask = np.zeros_like(old_gray)

    # Parámetros para ShiTomasi
    feature_params = dict(maxCorners=100, qualityLevel=0.3, minDistance=7, blockSize=7)

    # Parámetros para optical flow de Lucas-Kanade
    lk_params = dict(winSize=(15, 15), maxLevel=2, 
                     criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))

    # Obtener puntos para rastrear
    p0 = cv2.goodFeaturesToTrack(old_gray, mask=None, **feature_params)

    # Crear ventanas
    cv2.namedWindow('Video Original', cv2.WINDOW_NORMAL)
    cv2.namedWindow('Video con Optical Flow', cv2.WINDOW_NORMAL)
    cv2.namedWindow('Máscara de Movimiento', cv2.WINDOW_NORMAL)

    while True:
        # Leer el frame actual
        ret, frame = cap.read()
        if not ret:
            break

        # Convertir a escala de grises
        frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Calcular optical flow
        p1, st, err = cv2.calcOpticalFlowPyrLK(old_gray, frame_gray, p0, None, **lk_params)

        # Seleccionar puntos buenos
        if p1 is not None:
            good_new = p1[st == 1]
            good_old = p0[st == 1]

        # Crear una imagen para dibujar los vectores
        flow_img = frame.copy()
        
        # Resetear la máscara binaria
        binary_mask = np.zeros_like(frame_gray)

        # Dibujar los vectores de flujo óptico
        for i, (new, old) in enumerate(zip(good_new, good_old)):
            a, b = new.ravel()
            c, d = old.ravel()
            
            # Dibujar líneas para mostrar el movimiento
            mask = cv2.line(mask, (int(a), int(b)), (int(c), int(d)), (0, 255, 0), 2)
            flow_img = cv2.circle(flow_img, (int(a), int(b)), 5, (0, 0, 255), -1)
            
            # Calcular la magnitud del movimiento
            magnitude = np.sqrt((a-c)**2 + (b-d)**2)
            
            # Si hay movimiento significativo, marcar en la máscara binaria
            if magnitude > 1.0:  # Umbral ajustable
                cv2.circle(binary_mask, (int(a), int(b)), 10, 255, -1)

        # Combinar frame e imagen de flujo
        flow_img = cv2.add(flow_img, mask)
        
        # Mostrar resultados
        cv2.imshow('Video Original', frame)
        cv2.imshow('Video con Optical Flow', flow_img)
        cv2.imshow('Máscara de Movimiento', binary_mask)

        # Actualizar frame y puntos anteriores
        old_gray = frame_gray.copy()
        p0 = cv2.goodFeaturesToTrack(old_gray, mask=None, **feature_params)
        
        # Salir si se presiona ESC
        k = cv2.waitKey(30) & 0xff
        if k == 27:  # ESC
            break

    # Liberar recursos
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()