import cv2
import numpy as np
import sys

# Verificar argumentos de línea de comandos
if len(sys.argv) < 2:
    print("Uso: python optical_flow.py [video_file]")
    sys.exit()

# Parámetros para el flujo óptico
FLOW_SCALE = 5       # Escala para visualización de vectores
MOTION_THRESHOLD = 2  # Umbral para detección de movimiento
STEP = 10             # Espaciado entre vectores

# Inicializar captura de video
cap = cv2.VideoCapture(sys.argv[1])
if not cap.isOpened():
    print("Error al abrir el video")
    sys.exit()

# Leer primer frame
ret, prev_frame = cap.read()
if not ret:
    print("Error al leer el video")
    sys.exit()

prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
height, width = prev_gray.shape

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    # Convertir a escala de grises
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Calcular flujo óptico denso con Farneback
    flow = cv2.calcOpticalFlowFarneback(
        prev_gray, gray, None,
        pyr_scale=0.5,
        levels=3,
        winsize=15,
        iterations=3,
        poly_n=5,
        poly_sigma=1.2,
        flags=0
    )
    
    # Crear overlay para vectores
    overlay = frame.copy()
    
    # Crear máscara binaria
    mask = np.zeros_like(gray)
    mag, _ = cv2.cartToPolar(flow[...,0], flow[...,1])
    mask[mag > MOTION_THRESHOLD] = 255
    
    # Dibujar vectores de movimiento
    for y in range(0, height, STEP):
        for x in range(0, width, STEP):
            dx, dy = flow[y, x]
            if mag[y, x] > MOTION_THRESHOLD:
                x2 = int(x + dx * FLOW_SCALE)
                y2 = int(y + dy * FLOW_SCALE)
                cv2.line(overlay, (x, y), (x2, y2), (0, 255, 0), 1)
                cv2.circle(overlay, (x2, y2), 1, (0, 255, 0), -1)
    
    # Mostrar ventanas
    cv2.imshow('Video Original', frame)
    cv2.imshow('Flujo Optico', overlay)
    cv2.imshow('Mascara de Movimiento', mask)
    
    # Actualizar frame anterior
    prev_gray = gray.copy()
    
    # Salir con 'q'
    if cv2.waitKey(30) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()