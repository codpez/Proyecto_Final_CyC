import cv2
import numpy as np
from mvextractor.videocap import VideoCap

def main(video_path, threshold):
    # Inicializamos VideoCap y abrimos el video(tiene que ser h264)
    cap = VideoCap()
    if not cap.open(video_path):
        print("Error al abrir el video:", video_path)
        return

    # Usamos OpenCV para obtener propiedades del video: dimensiones y fps
    cap_cv = cv2.VideoCapture(video_path)
    if not cap_cv.isOpened():
        print("Error al abrir el video con OpenCV para obtener propiedades.")
        return
    width = int(cap_cv.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap_cv.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap_cv.get(cv2.CAP_PROP_FPS)
    cap_cv.release()
    
    # Calculamos el delay base en milisegundos (alrededor de 1000/fps)
    delay = int(1000 / fps) if fps > 0 else 30

    # Creamos tres ventanas para mostrar:
    cv2.namedWindow("Original", cv2.WINDOW_NORMAL)
    cv2.namedWindow("Con vectores de movimiento", cv2.WINDOW_NORMAL)
    cv2.namedWindow("Umbral binario", cv2.WINDOW_NORMAL)

    # Posicionamos las ventanas para que no se solapen
    espacio = 250  # espacio en píxeles entre ventanas
    cv2.moveWindow("Original", 0, 0)
    cv2.moveWindow("Con vectores de movimiento", width + espacio, 0)
    cv2.moveWindow("Umbral binario", (2 * (width + espacio)), 0)

    print("Controles: 'f' para acelerar, 's' para ralentizar, 'q' para salir.")

    while True:
        try:
            ret, frame, motion_vectors, frame_type, timestamp = cap.read()
        except Exception as e:
            print("Error al leer el frame:", e)
            break

        # Copias para cada ventana
        original_frame = frame.copy()
        overlay_frame = frame.copy()
        binary_mask = np.zeros((height, width), dtype=np.uint8)

        # Procesamos cada vector de movimiento si hay datos
        if motion_vectors.size > 0:
            for vector in motion_vectors:
                try:
                    # Extraemos los campos según la documentación:
                    # vector[1]: w, vector[2]: h, vector[5]: dst_x, vector[6]: dst_y,
                    # vector[7]: motion_x, vector[8]: motion_y, vector[9]: motion_scale
                    w = int(vector[1])*
                    h = int(vector[2])
                    dst_x = int(vector[5])
                    dst_y = int(vector[6])
                    motion_scale = vector[9] if vector[9] != 0 else 1
                    dx = vector[7] / motion_scale
                    dy = vector[8] / motion_scale
                    magnitude = np.sqrt(dx**2 + dy**2)
                except Exception as e:
                    print("Error al procesar un vector:", e)
                    continue

                if magnitude >= threshold:
                    # Calculamos la región del macrobloque
                    x0 = max(dst_x - w // 2, 0)
                    y0 = max(dst_y - h // 2, 0)
                    x1 = min(x0 + w, width)
                    y1 = min(y0 + h, height)
                    
                    # En la ventana de overlay se dibuja:
                    cv2.rectangle(overlay_frame, (x0, y0), (x1, y1), (255, 0, 0), 2)
                    start_point = (dst_x, dst_y)
                    end_point = (int(dst_x + dx), int(dst_y + dy))
                    cv2.arrowedLine(overlay_frame, start_point, end_point, (0, 255, 0), 2, tipLength=0.3)
                    
                    # En la máscara binaria se marca la región (todo a 255)
                    binary_mask[y0:y1, x0:x1] = 255

        # Mostramos las tres ventanas sincronizadas
        cv2.imshow("Original", original_frame)
        cv2.imshow("Con vectores de movimiento", overlay_frame)
        cv2.imshow("Umbral binario", binary_mask)

        # Espera 'delay' ms. Se pueden ajustar la velocidad de reproducción
        key = cv2.waitKey(delay) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('f'):
            # Acelerar: reducimos el delay (mínimo 1ms)
            delay = max(1, delay - 5)
            print("Acelerando, delay =", delay, "ms")
        elif key == ord('s'):
            # Ralentizar: aumentamos el delay
            delay += 5
            print("Ralentizando, delay =", delay, "ms")

    cap.release()
    cv2.destroyAllWindows()
    print("Procesamiento finalizado.")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Uso: python desplegar.py <ruta_video> <umbral>")
    else:
        video_path = sys.argv[1]
        threshold = float(sys.argv[2])
        main(video_path, threshold)
