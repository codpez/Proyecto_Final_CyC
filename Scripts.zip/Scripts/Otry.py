import cv2
import numpy as np
import sys

def main():
#-----------------Parser----------------------------------
    if len(sys.argv) < 2:
        print("Uso: python Otry.py ruta_del_video")
        sys.exit(1)
    
    video_path = sys.argv[1]

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("Error al abrir el video")
        sys.exit(1)
#-----------------------------------------------------------------
    # Leer el primer frame y convertirlo a escala de grises.
    ret, prev_frame = cap.read()
    if not ret:
        print("No se pudo leer el primer frame")
        sys.exit(1)
    # primer frame en grises
    prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
    
    # Generamos una imagen para dibujar las flechas de los vectores.
    hsv = np.zeros_like(prev_frame)
    hsv[..., 1] = 255  # Canal de saturación al máximo, si se desea visualizar en color.

    delay=30
    # Parámetros para muestrear los puntos donde se dibujan las flechas (cada step píxeles).
    step = 4  #8 #4 
    #####

    ### empezamos a leer el video
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        # convertimos los frames a gray scale
        frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Calculamos el flujo óptico denso con Farneback
        flow = cv2.calcOpticalFlowFarneback(prev_gray, frame_gray, None, 
                                            pyr_scale=0.5, levels=3, winsize=15,#15 
                                            iterations=3, poly_n=5, poly_sigma=1.2, flags=0)
        # Separa los componentes horizontal y vertical del flujo
        flow_x = flow[..., 0]
        flow_y = flow[..., 1]
        
        # Calculamos la magnitud y el ángulo de las componentes
        magnitude, angle = cv2.cartToPolar(flow_x, flow_y, angleInDegrees=True)

        # Creamos una copia del frame para dibujar las flechas
        draw_frame = frame.copy()
        
        # Dibujamos en una malla (cada step píxeles) los vectores de movimiento
        h, w = frame_gray.shape
        for y in range(0, h, step):
            for x in range(0, w, step):
                # Punto de inicio
                start_point = (x, y)
                # Calculamos el final del vector (escala la magnitud para visualización)
                dx = int(flow[y, x, 0] * 2)
                dy = int(flow[y, x, 1] * 2)
                end_point = (x + dx, y + dy)
                # Dibujamos la flecha en verde
                cv2.arrowedLine(draw_frame, start_point, end_point, color=(0, 255, 0), thickness=1, tipLength=0.3)
        
        # Generamos una máscara binaria a partir de la magnitud del flujo:
        # Definimos un umbral. Los píxeles con magnitud mayor se consideran en movimiento.
        threshold = 2.2
        ##############
        mask_binary = np.uint8(magnitude > threshold) * 255

        # Muestra las ventanas:
        cv2.imshow("Video Original", frame)
        cv2.imshow("Flujo Optico - Vectores de movimiento", draw_frame)
        cv2.imshow("Mascara de Movimiento", mask_binary)
        
        # Actualizamos el frame anterior
        prev_gray = frame_gray.copy()

        # Se espera por tecla, presiona 'q' para salir
        if cv2.waitKey(30) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
