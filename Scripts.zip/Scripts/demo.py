import cv2
import numpy as np
from mvextractor.videocap import VideoCap

def main(video_path, output_path, threshold):
    # Inicializamos VideoCap y abrimos el video H264.
    cap = VideoCap()
    if not cap.open(video_path):
        print("Error al abrir el video:", video_path)
        return

    # Para obtener las dimensiones y fps del video, se usa OpenCV.
    cap_cv = cv2.VideoCapture(video_path)
    if not cap_cv.isOpened():
        print("Error al abrir el video con OpenCV para obtener propiedades.")
        return
    width = int(cap_cv.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap_cv.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap_cv.get(cv2.CAP_PROP_FPS)
    cap_cv.release()

    # Configuración del video de salida (escala de grises).
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height), isColor=False)

    # Procesamos frame a frame usando VideoCap.read(), que internamente llama a grab() y retrieve().
    frame_idx = 0
    ret, frame, motion_vectors, frame_type, timestamp = cap.read()
    while ret:
        # Creamos una máscara negra (imagen en escala de grises).
        mask = np.zeros((height, width), dtype=np.uint8)

        # motion_vectors es un array de numpy de tipo int32 con forma (N, 10).
        # Si no hay vectores (por ejemplo, en un frame I), motion_vectors estará vacío.
        if motion_vectors.size > 0:
            for vector in motion_vectors:
                # Campos según la documentación:
                # vector[1]: w (ancho del macrobloque)
                # vector[2]: h (alto del macrobloque)
                # vector[5]: dst_x (coordenada x en el frame actual)
                # vector[6]: dst_y (coordenada y en el frame actual)
                # vector[7]: motion_x
                # vector[8]: motion_y
                # vector[9]: motion_scale
                w = int(vector[1])
                h = int(vector[2])
                dst_x = int(vector[5])
                dst_y = int(vector[6])
                motion_scale = vector[9] if vector[9] != 0 else 1  # evitar división por cero
                dx = vector[7] / motion_scale
                dy = vector[8] / motion_scale
                magnitude = np.sqrt(dx**2 + dy**2)

                if magnitude >= threshold:
                    # Calculamos la región correspondiente al macrobloque.
                    # dst_x y dst_y representan el centro del macrobloque.
                    x0 = max(dst_x - w // 2, 0)
                    y0 = max(dst_y - h // 2, 0)
                    x1 = min(x0 + w, width)
                    y1 = min(y0 + h, height)
                    mask[y0:y1, x0:x1] = 255

        # Escribimos la máscara en el video de salida.
        out.write(mask)

        # Leemos el siguiente frame.
        ret, frame, motion_vectors, frame_type, timestamp = cap.read()
        frame_idx += 1

    cap.release()
    out.release()
    print("Video procesado correctamente.")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 4:
        print("Uso: python demo.py <ruta_video_entrada> <ruta_video_salida> <umbral>")
    else:
        video_path = sys.argv[1]
        output_path = sys.argv[2]
        threshold = float(sys.argv[3])
        main(video_path, output_path, threshold)
