import cv2
import numpy as np
import mediapipe as mp
import sys

# ========= CONFIGURACIÓN =========
SCALE_FACTOR = 0.5
FLOW_SCALE = 12
MOTION_THRESHOLD = 1.2
BODY_RADIUS = 20  # Radio para landmarks corporales
FACE_RADIUS = 15   # Radio menor para landmarks faciales

# Inicializar modelos MediaPipe
mp_pose = mp.solutions.pose
mp_face = mp.solutions.face_mesh
pose = mp_pose.Pose(static_image_mode=False, model_complexity=1, min_detection_confidence=0.5)
face = mp_face.FaceMesh(static_image_mode=False, max_num_faces=1, refine_landmarks=True, min_detection_confidence=0.5)

# Landmarks clave (corporales + faciales)
BODY_LANDMARKS = {
    mp_pose.PoseLandmark.LEFT_WRIST: ("Muñeca Izq", 'body'),
    mp_pose.PoseLandmark.RIGHT_WRIST: ("Muñeca Der", 'body'),
    mp_pose.PoseLandmark.LEFT_ELBOW: ("Codo Izq", 'body'),
    mp_pose.PoseLandmark.RIGHT_ELBOW: ("Codo Der", 'body'),
    mp_pose.PoseLandmark.LEFT_SHOULDER: ("Hombro Izq", 'body'),
    mp_pose.PoseLandmark.RIGHT_SHOULDER: ("Hombro Der", 'body'),
    mp_pose.PoseLandmark.NOSE: ("Nariz", 'face'),
}

FACE_LANDMARK_IDS = [
    (10, "Frente"),          # Punto superior de la frente
    (152, "Mentón"),         # Punto central del mentón
    (234, "Ceja Izq"),       # Ceja izquierda
    (454, "Ceja Der"),       # Ceja derecha
    (145, "Boca Superior"),  # Labio superior
    (374, "Boca Inferior"),  # Labio inferior
]

# Paleta de colores
COLOR_PALETTE = {
    'body': (0, 255, 0),     # Verde para cuerpo
    'face': (255, 0, 255),   # Magenta para cara
    'boca': (0, 255, 255),   # Cyan para boca
    'ceja': (255, 255, 0)    # Amarillo para cejas
}

# ========= FUNCIONES AUXILIARES =========
def get_landmark_color(name):
    """Asigna color según región facial"""
    if 'boca' in name.lower():
        return COLOR_PALETTE['boca']
    if 'ceja' in name.lower():
        return COLOR_PALETTE['ceja']
    return COLOR_PALETTE['face']

# ========= INICIALIZACIÓN =========
if len(sys.argv) < 2:
    print("Uso: python seguimiento_integral.py [video_file]")
    sys.exit()

cap = cv2.VideoCapture(sys.argv[1])
if not cap.isOpened():
    print("Error al abrir el video")
    sys.exit()

ret, prev_frame = cap.read()
prev_frame = cv2.resize(prev_frame, None, fx=SCALE_FACTOR, fy=SCALE_FACTOR)
prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)

cv2.namedWindow("Video Original", cv2.WINDOW_NORMAL)
cv2.namedWindow("Vectores Movimiento", cv2.WINDOW_NORMAL)
cv2.namedWindow("Mapa Térmico", cv2.WINDOW_NORMAL)

# ========= BUCLE PRINCIPAL =========
while True:
    ret, frame = cap.read()
    if not ret: break
    
    frame = cv2.resize(frame, None, fx=SCALE_FACTOR, fy=SCALE_FACTOR)
    h, w = frame.shape[:2]
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    overlay = frame.copy()
    motion_heatmap = np.zeros((h, w, 3), dtype=np.uint8)
    
    # Procesar cuerpo y cara
    pose_results = pose.process(frame_rgb)
    face_results = face.process(frame_rgb)

    def process_landmarks(landmarks, radius, is_face=False):
        """Función genérica para procesar landmarks"""
        for landmark, (name, type) in landmarks.items():
            lm = pose_results.pose_landmarks.landmark[landmark]
            x = int(lm.x * w)
            y = int(lm.y * h)
            
            # Determinar radio y color
            current_radius = FACE_RADIUS if is_face else radius
            color = COLOR_PALETTE[type] if not is_face else get_landmark_color(name)
            
            # ROI
            x1, y1 = max(x-current_radius, 0), max(y-current_radius, 0)
            x2, y2 = min(x+current_radius, w), min(y+current_radius, h)
            
            if x2 <= x1 or y2 <= y1: continue
            
            # Flujo óptico
            prev_roi = prev_gray[y1:y2, x1:x2]
            curr_roi = frame_gray[y1:y2, x1:x2]
            
            features = cv2.goodFeaturesToTrack(prev_roi, 
                maxCorners=30, 
                qualityLevel=0.01,
                minDistance=3,
                blockSize=5)
            
            if features is not None and len(features) > 0:
                next_pts, status, _ = cv2.calcOpticalFlowPyrLK(
                    prev_roi, curr_roi, features, None,
                    winSize=(25,25),
                    maxLevel=3,
                    criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
                
                valid = status.ravel() == 1
                good_prev = features[valid].reshape(-1, 2)
                good_next = next_pts[valid].reshape(-1, 2)
                
                if len(good_prev) > 0:
                    vectors = good_next - good_prev
                    magnitudes = np.linalg.norm(vectors, axis=1)
                    valid_idx = magnitudes > MOTION_THRESHOLD
                    
                    # Convertir coordenadas
                    global_points = good_prev[valid_idx] + np.array([x1, y1])
                    vectors = vectors[valid_idx]
                    
                    # Dibujar vectores y mapa térmico
                    for (gx, gy), (dx, dy) in zip(global_points, vectors):
                        end = (int(gx + dx*FLOW_SCALE), int(gy + dy*FLOW_SCALE))
                        cv2.arrowedLine(overlay, (int(gx), int(gy)), end, color, 1, tipLength=0.15)
                        cv2.circle(motion_heatmap, (int(gx), int(gy)), 2, color, -1)

    # Procesar landmarks corporales
    if pose_results.pose_landmarks:
        process_landmarks(BODY_LANDMARKS, BODY_RADIUS)

    # Procesar landmarks faciales
    if face_results.multi_face_landmarks:
        for face_landmarks in face_results.multi_face_landmarks:
            for idx, name in FACE_LANDMARK_IDS:
                lm = face_landmarks.landmark[idx]
                x = int(lm.x * w)
                y = int(lm.y * h)
                
                # ROI facial
                x1, y1 = max(x-FACE_RADIUS, 0), max(y-FACE_RADIUS, 0)
                x2, y2 = min(x+FACE_RADIUS, w), min(y+FACE_RADIUS, h)
                
                if x2 <= x1 or y2 <= y1: continue
                
                # Flujo óptico facial
                prev_roi = prev_gray[y1:y2, x1:x2]
                curr_roi = frame_gray[y1:y2, x1:x2]
                
                features = cv2.goodFeaturesToTrack(prev_roi, 
                    maxCorners=20, 
                    qualityLevel=0.02,
                    minDistance=2,
                    blockSize=3)
                
                if features is not None and len(features) > 0:
                    next_pts, status, _ = cv2.calcOpticalFlowPyrLK(
                        prev_roi, curr_roi, features, None,
                        winSize=(15,15),
                        maxLevel=2,
                        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
                    
                    valid = status.ravel() == 1
                    good_prev = features[valid].reshape(-1, 2)
                    good_next = next_pts[valid].reshape(-1, 2)
                    
                    if len(good_prev) > 0:
                        vectors = good_next - good_prev
                        magnitudes = np.linalg.norm(vectors, axis=1)
                        valid_idx = magnitudes > MOTION_THRESHOLD
                        
                        # Convertir coordenadas
                        global_points = good_prev[valid_idx] + np.array([x1, y1])
                        vectors = vectors[valid_idx]
                        
                        # Color específico para características faciales
                        color = get_landmark_color(name)
                        
                        for (gx, gy), (dx, dy) in zip(global_points, vectors):
                            end = (int(gx + dx*FLOW_SCALE), int(gy + dy*FLOW_SCALE))
                            cv2.arrowedLine(overlay, (int(gx), int(gy)), end, color, 1, tipLength=0.2)
                            cv2.circle(motion_heatmap, (int(gx), int(gy)), 2, color, -1)

    # Mezclar mapa térmico con overlay
    overlay = cv2.addWeighted(overlay, 0.7, motion_heatmap, 0.3, 0)

    # Mostrar resultados
    cv2.imshow("Video Original", frame)
    cv2.imshow("Vectores Movimiento", overlay)
    cv2.imshow("Mapa Térmico", motion_heatmap)
    
    # Actualizar frame anterior
    prev_gray = frame_gray.copy()
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()