import cv2
import numpy as np
import mediapipe as mp
import sys

# Parámetros para flujo óptico
FLOW_SCALE = 10  # Ajustado para compensar el redimensionamiento
MOTION_THRESHOLD = 2

# Inicializar MediaPipe pose
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=False, model_complexity=1, enable_segmentation=False, min_detection_confidence=0.5)

# Leer archivo de video desde argumentos
if len(sys.argv) < 2:
    print("Uso: python optical_flow_mediapipe.py [video_file]")
    sys.exit()

video_path = sys.argv[1]
cap = cv2.VideoCapture(video_path)

ret, prev_frame = cap.read()
if not ret:
    print("No se pudo leer el primer frame.")
    sys.exit()

# Redimensionar al 50%
prev_frame = cv2.resize(prev_frame, None, fx=0.5, fy=0.5)
prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)

cv2.namedWindow("Video Original", cv2.WINDOW_NORMAL)
cv2.namedWindow("Flujo Óptico Filtrado", cv2.WINDOW_NORMAL)
cv2.namedWindow("Máscara Movimiento en Muñecas", cv2.WINDOW_NORMAL)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Redimensionar al 50%
    frame = cv2.resize(frame, None, fx=0.5, fy=0.5)
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = pose.process(frame_rgb)
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Máscara de regiones relevantes (muñecas)
    motion_mask = np.zeros_like(frame_gray, dtype=np.uint8)
    overlay = frame.copy()

    if results.pose_landmarks:
        h, w, _ = frame.shape

        # Lista de landmarks importantes
        keypoints = [
            mp_pose.PoseLandmark.NOSE,
            mp_pose.PoseLandmark.LEFT_EYE,
            mp_pose.PoseLandmark.RIGHT_EYE,
            mp_pose.PoseLandmark.LEFT_SHOULDER,
            mp_pose.PoseLandmark.RIGHT_SHOULDER,
            mp_pose.PoseLandmark.LEFT_ELBOW,
            mp_pose.PoseLandmark.RIGHT_ELBOW,
            mp_pose.PoseLandmark.LEFT_WRIST,
            mp_pose.PoseLandmark.RIGHT_WRIST,
            mp_pose.PoseLandmark.LEFT_HIP,
            mp_pose.PoseLandmark.RIGHT_HIP,
        ]

        # Convertir a coordenadas absolutas
        coords = []
        for kp in keypoints:
            lm = results.pose_landmarks.landmark[kp]
            x = int(lm.x * w)
            y = int(lm.y * h)
            coords.append((x, y))

        # Calcular bounding box que los contenga todos
        xs, ys = zip(*coords)
        x1, y1 = max(min(xs) - 20, 0), max(min(ys) - 50, 0)
        x2, y2 = min(max(xs) + 20, w), min(max(ys) + 20, h)

        # Crear máscara rectangular
        motion_mask[y1:y2, x1:x2] = 255
        cv2.rectangle(overlay, (x1, y1), (x2, y2), (0, 0, 255), 2)

        # Extraer ROI de los frames previo y actual
        prev_roi = prev_gray[y1:y2, x1:x2]
        curr_roi = frame_gray[y1:y2, x1:x2]

        # Detectar puntos clave en la ROI anterior
        corners = cv2.goodFeaturesToTrack(prev_roi, maxCorners=100, qualityLevel=0.01, minDistance=7, blockSize=5)

        # Calcular flujo óptico con Lucas-Kanade
        if corners is not None and len(corners) > 0:
            next_pts, status, err = cv2.calcOpticalFlowPyrLK(prev_roi, curr_roi, corners, None)

            # Filtrar puntos buenos
            good_prev = corners[status == 1]
            good_next = next_pts[status == 1]

            # Dibujar vectores de movimiento
            for (prev_x, prev_y), (next_x, next_y) in zip(good_prev, good_next):
                dx = next_x - prev_x
                dy = next_y - prev_y
                mag = np.hypot(dx, dy)
                
                if mag > MOTION_THRESHOLD:
                    # Convertir coordenadas a las del frame original
                    x_global = x1 + int(prev_x)
                    y_global = y1 + int(prev_y)
                    x2_global = x1 + int(next_x)
                    y2_global = y1 + int(next_y)
                    
                    cv2.line(overlay, (x_global, y_global), (x2_global, y2_global), (0, 255, 0), 1)
                    cv2.circle(overlay, (x2_global, y2_global), 1, (0, 255, 0), -1)

    # Mostrar ventanas
    cv2.imshow("Video Original", frame)
    cv2.imshow("Flujo Óptico Filtrado", overlay)
    cv2.imshow("Máscara Movimiento en Muñecas", motion_mask)

    # Preparar siguiente iteración
    prev_gray = frame_gray.copy()

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()