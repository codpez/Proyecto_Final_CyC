import cv2
import numpy as np
import mediapipe as mp
import sys

# Parámetros para flujo óptico
FLOW_SCALE = 5
MOTION_THRESHOLD = 2
STEP = 10
ROI_SIZE = 100

# Inicializar MediaPipe pose
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
pose = mp_pose.Pose(static_image_mode=False, model_complexity=1, enable_segmentation=False, min_detection_confidence=0.5)


# Leer archivo de video desde argumentos
if len(sys.argv) < 2:
    print("Uso: python optical_flow_mediapipe.py [video_file]")
    sys.exit()

video_path = sys.argv[1]
cap = cv2.VideoCapture(video_path)

ret, prev_frame = cap.read()
if not ret:
    print("No se pudo leer el primer frame.")
    sys.exit()

prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)

cv2.namedWindow("Video Original", cv2.WINDOW_NORMAL)
cv2.namedWindow("Flujo Óptico Filtrado", cv2.WINDOW_NORMAL)
cv2.namedWindow("Máscara Movimiento en Muñecas", cv2.WINDOW_NORMAL)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = pose.process(frame_rgb)
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Máscara de regiones relevantes (muñecas)
    motion_mask = np.zeros_like(frame_gray, dtype=np.uint8)

    if results.pose_landmarks:
        h, w, _ = frame.shape

        # Lista de landmarks importantes
        keypoints = [
            mp_pose.PoseLandmark.NOSE,
            mp_pose.PoseLandmark.LEFT_EYE,
            mp_pose.PoseLandmark.RIGHT_EYE,
            mp_pose.PoseLandmark.LEFT_SHOULDER,
            mp_pose.PoseLandmark.RIGHT_SHOULDER,
            mp_pose.PoseLandmark.LEFT_ELBOW,
            mp_pose.PoseLandmark.RIGHT_ELBOW,
            mp_pose.PoseLandmark.LEFT_WRIST,
            mp_pose.PoseLandmark.RIGHT_WRIST,
            mp_pose.PoseLandmark.LEFT_HIP,
            mp_pose.PoseLandmark.RIGHT_HIP,
        ]

    # Convertir a coordenadas absolutas
    coords = []
    for kp in keypoints:
        lm = results.pose_landmarks.landmark[kp]
        x = int(lm.x * w)
        y = int(lm.y * h)
        coords.append((x, y))

    # Calcular bounding box que los contenga todos
    xs, ys = zip(*coords)
    x1, y1 = max(min(xs) - 20, 0), max(min(ys) - 50, 0)  # aumentamos más hacia arriba
    x2, y2 = min(max(xs) + 20, w), min(max(ys) + 20, h)

    # Crear máscara rectangular
    motion_mask[y1:y2, x1:x2] = 255
    overlay = frame.copy()
    cv2.rectangle(overlay,(x1,y1),(x2,y2),(0,0,255),2)

    # Calcular flujo óptico denso
    flow = cv2.calcOpticalFlowFarneback(
        prev_gray, frame_gray, None,
        pyr_scale=0.5, levels=3, winsize=15,
        iterations=3, poly_n=5, poly_sigma=1.2, flags=0
    )

    # Magnitud y filtrado por umbral
    mag, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
    movement = np.zeros_like(mag, dtype=np.uint8)
    movement[mag > MOTION_THRESHOLD] = 255

    # Aplicar máscara solo a ROI
    movement = cv2.bitwise_and(movement, motion_mask)

    # Dibujar vectores en overlay
    height, width = frame_gray.shape
    for y in range(0, height, STEP):
        for x in range(0, width, STEP):
            if movement[y, x] > 0:
                dx, dy = flow[y, x]
                x2 = int(x + dx * FLOW_SCALE)
                y2 = int(y + dy * FLOW_SCALE)
                cv2.line(overlay, (x, y), (x2, y2), (0, 255, 0), 1)
                cv2.circle(overlay, (x2, y2), 1, (0, 255, 0), -1)

    # Mostrar ventanas
    cv2.imshow("Video Original", frame)
    cv2.imshow("Flujo Óptico Filtrado", overlay)
    cv2.imshow("Máscara Movimiento en Muñecas", movement)

    # Preparar siguiente iteración
    prev_gray = frame_gray.copy()

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
